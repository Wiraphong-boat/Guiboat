package com.example.administrator.guiboat;

import static org.junit.Assert.*;

public class MainActivityTest {

}