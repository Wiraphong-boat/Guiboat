package com.example.administrator.guiboat;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {
    ImageButton c2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        c2 = findViewById(R.id.song);
        c2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent c2 = new Intent(MainActivity.this,Listen.class);
                startActivities(new Intent[]{c2});
            }
        });
            }

    private void startActivities(Intent c2) {
      
    }

}

